# Pizza Tower Switch Port Decompilation
A decompilation of the Switch Port of Pizza Tower by D

### Downloads
Will be in releases

### Also...
This decomp still needs some work to compile right, which I won't do, as I'm not really intrested in the port itself, just the removal of FMOD

GameMaker Version: 2023.2 according to UTMT

## Thanks to
- D, for the original port
- QuantumV, for the Decompiler that I shouldn't even have
